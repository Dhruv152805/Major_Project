#!/usr/bin/env python3
"""
Arjuna Main Bringup Launch File

Brings up:
1. Static TF transforms (base_footprint -> base_link -> laser, imu)
2. Motor driver node (motor_controller/motor_node)
3. Wheel odometry node (arjuna_odometry/arjuna_ekf_odom_pub remapped to /wheel/odom)
4. IMU driver node (imu_bno055/bno055_i2c_node)
5. LIDAR driver node (sllidar_ros2/sllidar_node)
6. Sensor Fusion node (robot_localization/ekf_node publishing odom -> base_footprint TF)
7. RViz click publisher helper node (arjuna_odometry/arjuna_rviz_data_pub)
8. RViz visualization with default arjuna.rviz config
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess 
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch.conditions import IfCondition

def generate_launch_description():
    pkg_share = get_package_share_directory('arjuna_main')
    
    # Path to Nav2 parameters file and behavior trees
    nav2_params_file = os.path.join(pkg_share, 'config', 'nav2_params.yaml')
    default_bt_xml_file = os.path.join(pkg_share, 'behavior_trees', 'arjuna_nav_bt.xml')
    
    gui_arg = DeclareLaunchArgument(
        'gui', 
        default_value='True',
        description='Whether to start RViz'
    )
    
    serial_port_arg = DeclareLaunchArgument(
        'serial_port',
        default_value='/dev/ttyUSB0',
        description='LIDAR serial port'
    )
    
    drive_mode_arg = DeclareLaunchArgument(
        'drive_mode',
        default_value='differential',
        description='Drive mode: differential or mecanum'
    )

    motor_port_arg = DeclareLaunchArgument(
        'motor_port',
        default_value='/dev/ttyACM0',
        description='Motor controller serial port'
    )

    imu_device_arg = DeclareLaunchArgument(
        'imu_device',
        default_value='/dev/i2c-1',
        description='IMU I2C device path'
    )


    # Dynamic search for the latest saved map in the source maps directory, falling back to installed default
    src_maps_dir = '/home/arjuna/Arjuna_ws/src/arjuna_main/arjuna_main/maps'
    installed_map_path = os.path.join(pkg_share, 'maps', 'my_map.yaml')
    
    default_map_path = installed_map_path
    if os.path.exists(src_maps_dir):
        try:
            yaml_files = [f for f in os.listdir(src_maps_dir) if f.endswith('.yaml')]
            if yaml_files:
                yaml_files.sort(key=lambda x: os.path.getmtime(os.path.join(src_maps_dir, x)), reverse=True)
                default_map_path = os.path.join(src_maps_dir, yaml_files[0])
        except Exception:
            pass
            
    map_arg = DeclareLaunchArgument(
        'map',
        default_value=default_map_path,
        description='Full path to map yaml file to load'
    )

    # ========== TRANSFORM LAYER (Static TFs) ==========
    
    # AMCL node for localization (dynamically publishes map -> odom transform to correct drift)
    amcl_node = Node(
        package='nav2_amcl',
        executable='amcl',
        name='amcl',
        output='screen',
        parameters=[nav2_params_file]
    )
    
    base_link_broadcaster = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='base_link_broadcaster',
        arguments=['0', '0', '0.09', '0', '0', '0', 'base_footprint', 'base_link']
    )
    
    base_link_to_laser = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='base_link_to_laser',
        arguments=['0', '0', '0.09', '3.14159265', '0', '0', 'base_link', 'laser']
    )
    
    imu_broadcaster = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='imu_broadcaster',
        arguments=['0', '0', '0', '-1.570796325', '0', '0', 'base_link', 'imu']
    )
    
    # ========== SENSOR & DRIVER LAYER ==========
    
    # 1. New Motor Driver Node
    motor_driver = Node(
        package='motor_controller',
        executable='motor_node',
        name='motor_driver',
        output='screen',
        parameters=[{
            'port': LaunchConfiguration('motor_port'),
            'baudrate': 1000000,
            'drive_mode': LaunchConfiguration('drive_mode'),
            'speed_scaling': 10000,
            'tick_scaling': 2.5,
            'invert_y': False
        }]
    )
    
    # 2. Optimized Wheel Odometry Publisher
    wheel_odom = Node(
        package='arjuna_odometry',
        executable='arjuna_ekf_odom_pub',
        name='arjuna_ekf_odom_pub',
        parameters=[{
            'publish_tf': False,  # EKF publishes the TF
            'wheel_radius': 0.04,
            'wheel_base': 0.30,
            'ticks_per_revolution': 4096.0,
            'tick_scaling': 2.5,
            'odom_frame': 'odom',
            'base_frame': 'base_footprint'
        }],
        remappings=[
            ('/odom', '/wheel/odom'),
            ('/odom_data_quat', '/wheel/odom_data_quat'),
            ('/odom_data_euler', '/wheel/odom_data_euler')
        ]
    )
    
    # 3. IMU Node (BNO055 driver)
    imu_node = Node(
        package='imu_bno055',
        executable='bno055_i2c_node',
        name='imu_node',
        namespace='imu',
        parameters=[{
            'device': LaunchConfiguration('imu_device'),
            'address': 40,
            'frame_id': 'imu'
        }],
        remappings=[
            ('/data', '/imu/data'),
            ('/raw', '/imu/raw'),
            ('/mag', '/imu/mag'),
            ('/status', '/imu/status'),
            ('/temp', 'imu/temp'),
        ],
        output='screen'
    )
    
    # 4. LIDAR Node (RPLidar / SLlidar)
    lidar_node = Node(
        package='sllidar_ros2',
        executable='sllidar_node',
        name='sllidar_node',
        parameters=[{
            'channel_type': 'serial',
            'serial_port': LaunchConfiguration('serial_port'),
            'serial_baudrate': 460800,
            'frame_id': 'laser',
            'inverted': False,
            'angle_compensate': True,
            'scan_mode': 'Standard'
        }],
        output='screen'
    )

    
    # ========== FUSION LAYER ==========
    
    # robot_localization EKF fusing wheel odom and IMU to publish odom -> base_footprint TF
    robot_localization_node = Node(
        package='robot_localization',
        executable='ekf_node',
        name='robot_pose_ekf',
        output='screen',
        parameters=[{
            'frequency': 30.0,
            'sensor_timeout': 1.0,
            'two_d_mode': True,
            'publish_tf': True,
            
            'map_frame': 'map',
            'odom_frame': 'odom',
            'base_link_frame': 'base_footprint',
            'world_frame': 'odom',
            
            # Wheel odometry input (fuses velocities only)
            'odom0': '/wheel/odom',
            'odom0_config': [False, False, False,
                            False, False, False,
                            True,  False, False,
                            False, False, False,
                            False, False, False],
            'odom0_differential': False,
            
            # IMU input (fuses yaw and yaw rate)
            'imu0': '/imu/data',
            'imu0_config': [False, False, False,
                          False, False, True,
                          False, False, False,
                          False, False, True,
                          False, False, False],
            'imu0_differential': False,
            'imu0_relative': True,
            'imu0_remove_gravitational_acceleration': True,
            
            'debug': False
        }],
        remappings=[
            ('odometry/filtered', 'robot_pose_ekf/odom_combined')
        ]
    )
    
    # RViz click publisher
    rviz_data_pub = Node(
        package='arjuna_odometry',
        executable='arjuna_rviz_data_pub',
        name='rviz_data_pub',
        output='screen'
    )
    
    # ========== MAP SERVER & NAV2 LOCALIZATION/NAVIGATION ==========
    
    map_server_node = Node(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        parameters=[nav2_params_file, {
            'yaml_filename': LaunchConfiguration('map'),
            'topic_name': 'map',
            'frame_id': 'map'
        }]
    )
    
    controller_server_node = Node(
        package='nav2_controller',
        executable='controller_server',
        name='controller_server',
        output='screen',
        parameters=[nav2_params_file]
    )

    planner_server_node = Node(
        package='nav2_planner',
        executable='planner_server',
        name='planner_server',
        output='screen',
        parameters=[nav2_params_file]
    )

    behavior_server_node = Node(
        package='nav2_behaviors',
        executable='behavior_server',
        name='behavior_server',
        output='screen',
        parameters=[nav2_params_file]
    )

    bt_navigator_node = Node(
        package='nav2_bt_navigator',
        executable='bt_navigator',
        name='bt_navigator',
        output='screen',
        parameters=[nav2_params_file, {
            'default_nav_to_pose_bt_xml': default_bt_xml_file
        }]
    )
    
    lifecycle_manager_node = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_localization',
        output='screen',
        parameters=[{
            'use_sim_time': False,
            'autostart': True,
            'node_names': ['map_server', 'amcl', 'controller_server', 'planner_server', 'behavior_server', 'bt_navigator']
        }]
    )
    
    # ========== VISUALIZATION ==========
    
    rviz_config_path = os.path.join(pkg_share, 'rviz', 'arjuna.rviz')
    
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_path] if os.path.exists(rviz_config_path) else [],
        condition=IfCondition(LaunchConfiguration('gui')),
        output='screen'
    )
    
    return LaunchDescription([
        gui_arg,
        serial_port_arg,
        drive_mode_arg,
        motor_port_arg,
        imu_device_arg,
        map_arg,
        # Static TFs
        base_link_broadcaster,
        base_link_to_laser,
        imu_broadcaster,
        # Map Server & Localization & Nav2 Stack
        map_server_node,
        amcl_node,
        controller_server_node,
        planner_server_node,
        behavior_server_node,
        bt_navigator_node,
        lifecycle_manager_node,
        # Sensors & Drivers
        motor_driver,
        wheel_odom,
        imu_node,
        lidar_node,
        # Fusion
        robot_localization_node,
        # Utilities
        rviz_data_pub,
        rviz_node
    ])
