#!/usr/bin/env python3
"""
Arjuna Main SLAM Mapping Launch File

Brings up:
1. Static TF transforms (base_footprint -> base_link -> laser, imu)
2. Motor driver node (motor_controller/motor_node)
3. Wheel odometry node (arjuna_odometry/arjuna_ekf_odom_pub remapped to /wheel/odom)
4. IMU driver node (imu_bno055/bno055_i2c_node)
5. LIDAR driver node (sllidar_ros2/sllidar_node)
6. Sensor Fusion node (robot_localization/ekf_node publishing odom -> base_footprint TF, remapped to /odom)
7. SLAM node (slam_toolbox/async_slam_toolbox_node publishing map -> odom TF)
8. RViz visualization with default slam.rviz config
"""

from lark import parse_tree_builder
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch.conditions import IfCondition

def generate_launch_description():
    pkg_share = get_package_share_directory('arjuna_main')
    
    serial_port_arg = DeclareLaunchArgument(
        'serial_port',
        default_value='/dev/ttyUSB0',
        description='LIDAR serial port'
    )
    
    drive_mode_arg = DeclareLaunchArgument(
        'drive_mode',
        default_value='differential',
        description='Drive mode: differential or mecanum'
    )

    motor_port_arg = DeclareLaunchArgument(
        'motor_port',
        default_value='/dev/ttyACM0',
        description='Motor controller serial port'
    )

    imu_device_arg = DeclareLaunchArgument(
        'imu_device',
        default_value='/dev/i2c-1',
        description='IMU I2C device path'
    )

    # ========== TRANSFORM LAYER (Static TFs) ==========
    
    base_link_broadcaster = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='base_link_broadcaster',
        arguments=['0', '0', '0.09', '0', '0', '0', 'base_footprint', 'base_link']
    )
    
    base_link_to_laser = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='base_link_to_laser',
        arguments=['0', '0', '0.09', '3.14159265', '0', '0', 'base_link', 'laser']
    )
    
    imu_broadcaster = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='imu_broadcaster',
        arguments=['0', '0', '0', '-1.570796325', '0', '0', 'base_link', 'imu']
    )
    
    # ========== SENSOR & DRIVER LAYER ==========
    
    # 1. New Motor Driver Node
    motor_driver = Node(
        package='motor_controller',
        executable='motor_node',
        name='motor_driver',
        output='screen',
        parameters=[{
            'port': LaunchConfiguration('motor_port'),
            'baudrate': 1000000,
            'drive_mode': LaunchConfiguration('drive_mode'),
            'speed_scaling': 10000,
            'tick_scaling': 2.5,
            'invert_y': False
        }]
    )
    
    # 2. Optimized Wheel Odometry Publisher
    wheel_odom = Node(
        package='arjuna_odometry',
        executable='arjuna_ekf_odom_pub',
        name='arjuna_ekf_odom_pub',
        parameters=[{
            'publish_tf': False,  # EKF publishes the TF
            'wheel_radius': 0.04,
            'wheel_base': 0.30,
            'ticks_per_revolution': 4096.0,
            'tick_scaling': 2.5,
            'odom_frame': 'odom',
            'base_frame': 'base_footprint'
        }],
        remappings=[
            ('/odom', '/wheel/odom'),
            ('/odom_data_quat', '/wheel/odom_data_quat'),
            ('/odom_data_euler', '/wheel/odom_data_euler')
        ]
    )
    
    # 3. IMU Node (BNO055 driver)
    imu_node = Node(
        package='imu_bno055',
        executable='bno055_i2c_node',
        name='imu_node',
        namespace='imu',
        parameters=[{
            'device': LaunchConfiguration('imu_device'),
            'address': 40,
            'frame_id': 'imu'
        }],
        remappings=[
            ('/data', '/imu/data'),
            ('/raw', '/imu/raw'),
            ('/mag', '/imu/mag'),
            ('/status', '/imu/status'),
            ('/temp', 'imu/temp'),
        ],
        output='screen'
    )
    
    # 4. LIDAR Node (RPLidar / SLlidar)
    lidar_node = Node(
        package='sllidar_ros2',
        executable='sllidar_node',
        name='sllidar_node',
        parameters=[{
            'channel_type': 'serial',
            'serial_port': LaunchConfiguration('serial_port'),
            'serial_baudrate': 460800,
            'frame_id': 'laser',
            'inverted': False,
            'angle_compensate': True,
            'scan_mode': 'Standard'
        }],
        output='screen'
    )

    
    # ========== FUSION LAYER ==========
    
    # robot_localization EKF fusing wheel odom and IMU to publish odom -> base_footprint TF
    robot_localization_node = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_fusion',
        output='screen',
        parameters=[{
            'frequency': 30.0,
            'sensor_timeout': 1.0,
            'two_d_mode': True,
            'publish_tf': True,
            
            'odom_frame': 'odom',
            'base_link_frame': 'base_footprint',
            'world_frame': 'odom',
            
            # Wheel odometry input (fuses velocities only)
            'odom0': '/wheel/odom',
            'odom0_config': [False, False, False,
                            False, False, False,
                            True,  False, False,
                            False, False, True,
                            False, False, False],
            'odom0_differential': False,
            
            # IMU input (fuses yaw and yaw rate)
            'imu0': '/imu/data',
            'imu0_config': [False, False, False,
                          False, False, True,
                          False, False, False,
                          False, False, True,
                          False, False, False],
            'imu0_differential': False,
            'imu0_relative': True,
            'imu0_remove_gravitational_acceleration': True,
            
            'debug': False
        }],
        remappings=[
            ('/odometry/filtered', '/odom')  # Output as standard /odom for slam_toolbox
        ]
    )
    
    # ========== SLAM LAYER ==========
    
    slam_toolbox_node = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[{
            'use_sim_time': False,
            'base_frame': 'base_footprint',
            'odom_frame': 'odom',
            'map_frame': 'map',
            'scan_topic': '/scan',
            'mode': 'mapping',
            
            'minimum_travel_distance': 0.01,
            'minimum_travel_heading': 0.01,
            'minimum_time_interval': 0.1,
            
            'transform_publish_period': 0.02,
            'transform_timeout': 0.2,
            'tf_buffer_duration': 30.0,
            
            'resolution': 0.05,
            'max_laser_range': 12.0,
            'map_update_interval': 1.0,
            
            'throttle_scans': 1,
            'stack_size_to_use': 40000000,
            'enable_interactive_mode': True,
            
            'do_loop_closing': True,
            'loop_search_maximum_distance': 3.0,
            'loop_match_minimum_chain_size': 10,
            
            'scan_buffer_size': 10,
            'scan_buffer_maximum_scan_distance': 10.0,
            'link_match_minimum_response_fine': 0.1,
            'link_scan_maximum_distance': 1.5,
            'correlation_search_space_dimension': 0.5,
            'correlation_search_space_resolution': 0.01
        }]
    )
    
    # ========== VISUALIZATION ==========
    
    rviz_config_path = os.path.join(pkg_share, 'rviz', 'slam.rviz')
    
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_path] if os.path.exists(rviz_config_path) else [],
        output='screen'
    )
    
    # ========== AUTOMATIC MAP SAVER ==========
    # Determine the map save path dynamically in the source directory for persistence
    maps_dir = '/home/arjuna/Arjuna_ws/src/arjuna_main/arjuna_main/maps'
    os.makedirs(maps_dir, exist_ok=True)
    
    # Check if default 'my_map' exists, if so increment to 'my_map1', 'my_map2', etc.
    if not os.path.exists(os.path.join(maps_dir, 'my_map.yaml')):
        map_name = 'my_map'
    else:
        i = 1
        while os.path.exists(os.path.join(maps_dir, f'my_map{i}.yaml')):
            i += 1
        map_name = f'my_map{i}'
        
    map_path = os.path.join(maps_dir, map_name)
    
    # Event handler to save the map automatically when RViz is closed
    save_map_on_exit = RegisterEventHandler(
        OnProcessExit(
            target_action=rviz_node,
            on_exit=[
                Node(
                    package='nav2_map_server',
                    executable='map_saver_cli',
                    name='map_saver',
                    output='screen',
                    arguments=['-f', map_path],
                    parameters=[{'use_sim_time': False}]
                )
            ]
        )
    )
    
    return LaunchDescription([
        serial_port_arg,
        drive_mode_arg,
        motor_port_arg,
        imu_device_arg,
        # Static TFs
        base_link_broadcaster,
        base_link_to_laser,
        imu_broadcaster,
        # Sensors & Drivers
        motor_driver,
        wheel_odom,
        imu_node,
        lidar_node,
        # Fusion
        robot_localization_node,
        # SLAM
        slam_toolbox_node,
        # RViz
        rviz_node,
        # Auto Map Saver on RViz exit
        save_map_on_exit
    ])
